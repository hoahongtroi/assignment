﻿Public Class Fmenu

    Private Sub SinhVienToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SinhVienToolStripMenuItem.Click
        frmsinhvien.Show()


    End Sub
End Class